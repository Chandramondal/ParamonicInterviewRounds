﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleEnryLedgerApp.Domain
{
    public class CardDetails : CustomerDto
    {
        public Guid Id { get; set; }
        public string AccountNo { get; set; }
        public string AccountName { get; set; }
        public DateTime Expiry { get; set; }
        public double BalanceAmount { get; set; } = 0;
    }

    public enum EType
    {
        Credit,
        Debit
    }
}
