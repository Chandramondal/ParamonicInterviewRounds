﻿using SingleEnryLedgerApp.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleEnryLedgerApp.ApplicationLayer.Customer
{
    public class CustomerService : ICustomerService
    {
        public static List<CustomerDto> customerDtolist = new List<CustomerDto>();
        public static List<CardDetails> CardDetailsList = new List<CardDetails>();
        private static object _syncObject = new object();
        public void AddCustomer(string name, string place, string email, string phoneno)
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentNullException("name is empty");

            if (string.IsNullOrEmpty(place))
                throw new ArgumentNullException("place");

            if (string.IsNullOrEmpty(email))
                throw new ArgumentNullException("email");
            if (string.IsNullOrEmpty(phoneno))
                throw new ArgumentNullException("phoneno");

            CustomerDto customer = new CustomerDto()
            {
                CustomerID = new Guid(),
                CustomerName = name,
                Address = place,
                EmailId = email,
                PhoneNo = phoneno
            };
            customerDtolist.Add(customer);
         }

        public CardDetails CardDetailsForcustomer(CustomerDto customerDto)
        {
            CardDetails cardDetails = new CardDetails();
            if (customerDto != null)
            {
                if(CardDetailsList!=null)
                {
                    var res = CardDetailsList.Find(x => x.CustomerID == customerDto.CustomerID);
                    if (res != null)
                    {
                        Console.WriteLine("Already present in the database");
                        return null;
                    }
                }
                cardDetails.CustomerID = customerDto.CustomerID;
                cardDetails.CustomerName = customerDto.CustomerName;
                cardDetails.Address = customerDto.Address;
                cardDetails.EmailId = customerDto.EmailId;
                cardDetails.PhoneNo = customerDto.PhoneNo;
                cardDetails.AccountName = customerDto.CustomerName;
                cardDetails.AccountNo = "56784543225";
                cardDetails.BalanceAmount = 100;

            }
            CardDetailsList.Add(cardDetails);
            return cardDetails;
        }

        public double CheckBalance(CardDetails cardDetails)
        {
            return cardDetails.BalanceAmount;
        }

   
        public void Credit(CardDetails cardDetails)
        {
            ProductDetails productDetails = new ProductDetails()
            {
                ProductId = "prod-1",
                ProductName = "prod-1",
                ProductPrice = 500
            };

          UpdateBalanceSheet(cardDetails, productDetails, EType.Credit);
        }

        public void Debit(CardDetails cardDetails)
        {
            ProductDetails productDetails = new ProductDetails()
            {
                ProductId = "prod-1",
                ProductName = "prod-1",
                ProductPrice = 500
            };

            UpdateBalanceSheet(cardDetails, productDetails, EType.Debit);
        }

        public void UpdateBalanceSheet(CardDetails cardDetails, ProductDetails productDetails, EType etype)
        {
            lock (_syncObject)
            {
                if (etype==EType.Credit)
                {
                    cardDetails.BalanceAmount += productDetails.ProductPrice;
                }
                else
                {
                    cardDetails.BalanceAmount -= productDetails.ProductPrice;
                }
            }
        }
    }


}
