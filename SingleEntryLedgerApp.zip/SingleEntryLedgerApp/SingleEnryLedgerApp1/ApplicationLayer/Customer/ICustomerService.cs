﻿using SingleEnryLedgerApp.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleEnryLedgerApp.ApplicationLayer.Customer
{
    public interface ICustomerService
    {
        void AddCustomer(string name, string place, string email, string phoneno);
        CardDetails CardDetailsForcustomer(CustomerDto customerDto);
        double CheckBalance(CardDetails cardDetails);
        void Credit(CardDetails cardDetails);
        void Debit(CardDetails cardDetails);
        void UpdateBalanceSheet(CardDetails cardDetails, ProductDetails productDetails, EType etype);
        
        }
}
