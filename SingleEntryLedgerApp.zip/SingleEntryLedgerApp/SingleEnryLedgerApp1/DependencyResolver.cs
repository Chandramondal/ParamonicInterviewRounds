﻿using SingleEnryLedgerApp.ApplicationLayer.Customer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;

namespace SingleEnryLedgerApp
{
    public static class DependencyResolver
    {
        private static object _syncObject = new object();
        private static IServiceProvider _serviceProvider;

        private static ServiceCollection ServiceRegistryCollections { get; set; } = new ServiceCollection();

        /// <summary>
        /// Initialize dependencies
        /// </summary>
        /// <returns>Returns ServiceProvider</returns>
        public static IServiceProvider InitializeDependencies
        {
            get
            {
                lock (_syncObject)
                {
                    if (_serviceProvider != null)
                        return _serviceProvider;

                    ServiceRegistryCollections.AddSingleton<ICustomerService, CustomerService>();
                    _serviceProvider = ServiceRegistryCollections.BuildServiceProvider();
                    return _serviceProvider;
                }


            }
        }
    }
}
