﻿using SingleEnryLedgerApp.ApplicationLayer.Customer;
using System;
using Microsoft.Extensions.DependencyInjection;
using SingleEnryLedgerApp.Domain;

namespace SingleEnryLedgerApp
{

    class Program
    {
        static void Main(string[] args)
        {
            var customerService = DependencyResolver.InitializeDependencies.GetService<ICustomerService>();
            customerService.AddCustomer("Chandra","Kolkata","Chandra@gmail.com","12345678");
            CustomerDto customerDto = new CustomerDto()
            {
                CustomerName = "Chandra",
                Address = "Kolkata",
                EmailId = "Chandra@gmail.com",
                PhoneNo = "12345678"
            };
            CardDetails details= customerService.CardDetailsForcustomer(customerDto);
            customerService.Credit(details);
            customerService.Debit(details);
            double currentBalance= customerService.CheckBalance(details);
            Console.WriteLine("Current Balance is:"+ currentBalance);

        }
    }
}
