﻿using System;

namespace SingleEntryLedgerApp
{
    public class Class1
    {
    }
}
