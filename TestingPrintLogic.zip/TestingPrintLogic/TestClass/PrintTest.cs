﻿using System;
using TestingPrintLogic;
using Xunit;

namespace TestClass
{
    public class PrintTest
    {
           public PrintTest()
            {

            }

            [Fact]
            public void WhenIntValueisDevidedbyboth3And5()
            {
                string result = Print.PrintLogic(15);
                Assert.Equal("FizzBuzz", result);
            }

            [Fact]
            public void WhenIntValueisDevidedby3()
            {
                string result = Print.PrintLogic(15);
                Assert.Equal("Fizz", result);
            }

            [Fact]
            public void WhenIntValueisDevidedby5()
            {
                string result = Print.PrintLogic(15);
                Assert.Equal("Buzz", result);
            }

            [Fact]
            public void WhenValueisLessthan3()
            {
                string result = Print.PrintLogic(0);
                Assert.Equal("Unknown", result);
            }
        }
    
}
