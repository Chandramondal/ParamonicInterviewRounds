﻿using System;
using Xunit;

namespace TestingPrintLogic
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter your no:");
                int val = Convert.ToInt32(Console.ReadLine());
                string output = Print.PrintLogic(val);
                Console.WriteLine("Result is: " + output);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }

    public class Print
    {
        public static string PrintLogic(int value)
        {
            string result = String.Empty;
            try
            {
                if (value >= 3)
                {
                    if (value % 3 == 0 && value % 5 == 0)
                    {
                        result = "FizzBuzz";
                    }
                    else if (value % 3 == 0)
                    {
                        result = "Fizz";
                    }
                    else if (value % 5 == 0)
                    {
                        result = "Buzz";
                    }
                }

                else
                {
                    result = "Unknown";
                }

            }
            catch (Exception ex)
            {
                result = "Invalid input";
            }
            return result;
        }
    }

 

}
